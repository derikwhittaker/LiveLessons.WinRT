﻿using System;

namespace LL.FlipView.DataModel
{
    public class DashboardItem
    {
        public string Name { get; set; }

        public string Color { get; set; }

        public Type PageType { get; set; }
    }
}
