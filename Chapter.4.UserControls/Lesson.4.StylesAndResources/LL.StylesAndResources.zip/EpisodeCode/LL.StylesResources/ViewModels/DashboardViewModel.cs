﻿
using Metro.LL.Common;

namespace LL.StylesResources.ViewModels
{
    public class DashboardViewModel : BaseViewModel
    {
        public DashboardViewModel()
        {
            PageTitle = "Learning to use the Styles";

        }

    }
}
