using System;

namespace LL.GridView.DataModel
{
    public class DashboardItem
    {
        public string Name { get; set; }

        public string Color { get; set; }

        public Type PageType { get; set; }
    }
}