using System.Collections.Generic;

namespace LL.GridView.DataModel
{
    public class ItemGroup
    {
        public string Header { get; set; }

        public List<Item> Items { get; set; }
    }
}