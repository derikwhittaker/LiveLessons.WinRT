﻿// Type: Windows.UI.Xaml.Window
// Assembly: Windows, Version=255.255.255.255, Culture=neutral, PublicKeyToken=null
// Assembly location: C:\Program Files (x86)\Windows Kits\8.0\References\CommonConfiguration\Neutral\Windows.winmd

using System.Runtime.CompilerServices;
using Windows.Foundation;
using Windows.Foundation.Metadata;
using Windows.UI.Core;

namespace Windows.UI.Xaml
{
  /// <summary>
  /// Represents an application window.
  /// </summary>
  [WebHostHidden]
  [Threading(ThreadingModel.Both)]
  [Version(100794368)]
  [MarshalingBehavior(MarshalingType.Agile)]
  [Static(typeof (IWindowStatics), 100794368)]
  public sealed class Window : IWindow
  {
    /// <summary>
    /// Attempts to activate the application window by bringing it to the foreground and setting the input focus to it.
    /// </summary>
    [MethodImpl]
    public void Activate();
    /// <summary>
    /// Closes the application window.
    /// </summary>
    [MethodImpl]
    public void Close();
    /// <summary>
    /// Gets the height and width of the application window, as a Rect value.
    /// </summary>
    /// 
    /// <returns>
    /// A value that reports the height and width of the application window.
    /// </returns>
    public Rect Bounds { [MethodImpl] get; }
    /// <summary>
    /// Gets or sets the visual root of an application window.
    /// </summary>
    /// 
    /// <returns>
    /// The visual root of an application window.
    /// </returns>
    public UIElement Content { [MethodImpl] get; [MethodImpl] set; }
    /// <summary>
    /// Gets an internal core object for the application window.
    /// </summary>
    /// 
    /// <returns>
    /// A CoreWindow object.
    /// </returns>
    public CoreWindow CoreWindow { [MethodImpl] get; }
    /// <summary>
    /// Gets the CoreDispatcher object for the Window, which is generally the CoreDispatcher for the UI thread.
    /// </summary>
    /// 
    /// <returns>
    /// An object that references the thread for the Window.
    /// </returns>
    public CoreDispatcher Dispatcher { [MethodImpl] get; }
    /// <summary>
    /// Gets a value that reports whether the window is visible.
    /// </summary>
    /// 
    /// <returns>
    /// True if the window is visible; false if the window is not visible.
    /// </returns>
    public bool Visible { [MethodImpl] get; }
    /// <summary>
    /// Gets the currently activated window for an application.
    /// </summary>
    /// 
    /// <returns>
    /// The currently activated window.
    /// </returns>
    public static Window Current { [MethodImpl] get; }
    /// <summary>
    /// Occurs when the window has successfully been activated.
    /// </summary>
    public event WindowActivatedEventHandler Activated;
    /// <summary>
    /// Occurs when the window has closed.
    /// </summary>
    public event WindowClosedEventHandler Closed;
    /// <summary>
    /// Occurs when the window has rendered or changed its rendering size.
    /// </summary>
    public event WindowSizeChangedEventHandler SizeChanged;
    /// <summary>
    /// Occurs when the value of the Visible property changes.
    /// </summary>
    public event WindowVisibilityChangedEventHandler VisibilityChanged;
  }
}
