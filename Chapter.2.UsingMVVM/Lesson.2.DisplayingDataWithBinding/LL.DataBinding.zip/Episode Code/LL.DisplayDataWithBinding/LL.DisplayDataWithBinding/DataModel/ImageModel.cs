﻿using Metro.LL.Common;

namespace LL.IntroToMVVM.DataModel
{
    public class ImageModel : BaseViewModel
    {
        public string DisplayValue { get; set; }

        public string ImageUri { get; set; }


    }
}
