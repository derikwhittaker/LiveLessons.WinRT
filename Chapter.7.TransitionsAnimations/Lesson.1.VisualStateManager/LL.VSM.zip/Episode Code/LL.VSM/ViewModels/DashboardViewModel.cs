﻿namespace LL.VSM.ViewModels
{
    public class DashboardViewModel : Metro.LL.Common.BaseViewModel
    {
        public DashboardViewModel()
        {
            PageTitle = "Learning to use the Visual State Manager";
            
        }

    }
}
