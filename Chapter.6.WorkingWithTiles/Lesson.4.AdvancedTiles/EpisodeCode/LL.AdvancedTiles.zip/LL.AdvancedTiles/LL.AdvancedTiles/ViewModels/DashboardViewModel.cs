﻿using System;
using System.Diagnostics;
using GalaSoft.MvvmLight.Command;
using Metro.LL.Common;
using NotificationsExtensions.TileContent;
using Windows.ApplicationModel.Core;
using Windows.UI.Notifications;

namespace LL.AdvancedTiles.ViewModels
{
    public class DashboardViewModel : BaseViewModel
    {
        private RelayCommand _updateStaticLiveTileCommand;
        private RelayCommand _futureLiveTileCommand;
        private RelayCommand _clearLiveTileCommand;
        private bool _expireContent;
        private RelayCommand _queryFutureLiveTileCommand;

        public DashboardViewModel()
        {
            PageTitle = "Advanced Tiles";
        }

        #region Clear Tiles

        #endregion

        #region Future Tiles

        
        #endregion

        #region Static Tiles


        #endregion

    }
}
