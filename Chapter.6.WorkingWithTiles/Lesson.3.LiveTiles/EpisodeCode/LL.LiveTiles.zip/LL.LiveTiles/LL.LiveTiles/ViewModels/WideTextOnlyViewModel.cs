using NotificationsExtensions.TileContent;
using Windows.ApplicationModel.Core;
using Windows.UI.Notifications;

namespace LL.LiveTiles.ViewModels
{
    public class WideTextOnlyViewModel : SubpageBaseViewModel
    {
        protected override void CreateTile()
        {
        }
    }
}