using NotificationsExtensions.TileContent;
using Windows.ApplicationModel.Core;
using Windows.UI.Notifications;

namespace LL.LiveTiles.ViewModels
{
    public class SquareBlockWithHeaderViewModel : SubpageBaseViewModel
    {

        protected override void CreateTile()
        {
        }

    }
}