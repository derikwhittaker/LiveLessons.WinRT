using NotificationsExtensions.TileContent;
using Windows.ApplicationModel.Core;
using Windows.UI.Notifications;

namespace LL.LiveTiles.ViewModels
{
    public class WideImageImageOnlyViewModel : SubpageBaseViewModel
    {
        public WideImageImageOnlyViewModel()
        {
            this.ImagePath = "Images/LiveTileImage_310x150.png";
        }

        protected override void CreateTile()
        {
        }
    }
}