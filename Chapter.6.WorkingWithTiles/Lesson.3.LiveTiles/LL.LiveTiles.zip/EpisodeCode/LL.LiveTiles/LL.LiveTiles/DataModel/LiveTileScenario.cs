﻿using LL.LiveTiles.ViewModels;

namespace LL.LiveTiles.DataModel
{
    public class LiveTileScenario
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }

    public class DashboardSampleData : DashboardViewModel
    {
        
    }
}
